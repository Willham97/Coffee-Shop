﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtemploy1 = New System.Windows.Forms.TextBox()
        Me.Labelemploy = New System.Windows.Forms.Label()
        Me.Txtemploy2 = New System.Windows.Forms.TextBox()
        Me.Txtemploy3 = New System.Windows.Forms.TextBox()
        Me.Labelphon = New System.Windows.Forms.Label()
        Me.Labelhours = New System.Windows.Forms.Label()
        Me.Txtphone1 = New System.Windows.Forms.TextBox()
        Me.Txtphone2 = New System.Windows.Forms.TextBox()
        Me.Txtphone3 = New System.Windows.Forms.TextBox()
        Me.Txthours1 = New System.Windows.Forms.TextBox()
        Me.Txthour2 = New System.Windows.Forms.TextBox()
        Me.Txthour3 = New System.Windows.Forms.TextBox()
        Me.Bntprint = New System.Windows.Forms.Button()
        Me.Bntnew = New System.Windows.Forms.Button()
        Me.Bnthome = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Txtemploy1
        '
        Me.Txtemploy1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtemploy1.ForeColor = System.Drawing.Color.White
        Me.Txtemploy1.Location = New System.Drawing.Point(54, 73)
        Me.Txtemploy1.Name = "Txtemploy1"
        Me.Txtemploy1.Size = New System.Drawing.Size(133, 26)
        Me.Txtemploy1.TabIndex = 0
        '
        'Labelemploy
        '
        Me.Labelemploy.AutoSize = True
        Me.Labelemploy.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelemploy.ForeColor = System.Drawing.Color.White
        Me.Labelemploy.Location = New System.Drawing.Point(50, 30)
        Me.Labelemploy.Name = "Labelemploy"
        Me.Labelemploy.Size = New System.Drawing.Size(125, 20)
        Me.Labelemploy.TabIndex = 1
        Me.Labelemploy.Text = "Employee Name"
        '
        'Txtemploy2
        '
        Me.Txtemploy2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtemploy2.ForeColor = System.Drawing.Color.White
        Me.Txtemploy2.Location = New System.Drawing.Point(54, 136)
        Me.Txtemploy2.Name = "Txtemploy2"
        Me.Txtemploy2.Size = New System.Drawing.Size(133, 26)
        Me.Txtemploy2.TabIndex = 2
        '
        'Txtemploy3
        '
        Me.Txtemploy3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtemploy3.ForeColor = System.Drawing.Color.White
        Me.Txtemploy3.Location = New System.Drawing.Point(54, 195)
        Me.Txtemploy3.Name = "Txtemploy3"
        Me.Txtemploy3.Size = New System.Drawing.Size(133, 26)
        Me.Txtemploy3.TabIndex = 3
        '
        'Labelphon
        '
        Me.Labelphon.AutoSize = True
        Me.Labelphon.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelphon.ForeColor = System.Drawing.Color.White
        Me.Labelphon.Location = New System.Drawing.Point(259, 30)
        Me.Labelphon.Name = "Labelphon"
        Me.Labelphon.Size = New System.Drawing.Size(115, 20)
        Me.Labelphon.TabIndex = 4
        Me.Labelphon.Text = "Phone Number"
        '
        'Labelhours
        '
        Me.Labelhours.AutoSize = True
        Me.Labelhours.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelhours.ForeColor = System.Drawing.Color.White
        Me.Labelhours.Location = New System.Drawing.Point(445, 30)
        Me.Labelhours.Name = "Labelhours"
        Me.Labelhours.Size = New System.Drawing.Size(119, 20)
        Me.Labelhours.TabIndex = 5
        Me.Labelhours.Text = "Hours Available"
        '
        'Txtphone1
        '
        Me.Txtphone1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtphone1.ForeColor = System.Drawing.Color.White
        Me.Txtphone1.Location = New System.Drawing.Point(263, 73)
        Me.Txtphone1.Name = "Txtphone1"
        Me.Txtphone1.Size = New System.Drawing.Size(133, 26)
        Me.Txtphone1.TabIndex = 6
        '
        'Txtphone2
        '
        Me.Txtphone2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtphone2.ForeColor = System.Drawing.Color.White
        Me.Txtphone2.Location = New System.Drawing.Point(263, 136)
        Me.Txtphone2.Name = "Txtphone2"
        Me.Txtphone2.Size = New System.Drawing.Size(133, 26)
        Me.Txtphone2.TabIndex = 7
        '
        'Txtphone3
        '
        Me.Txtphone3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtphone3.ForeColor = System.Drawing.Color.White
        Me.Txtphone3.Location = New System.Drawing.Point(263, 195)
        Me.Txtphone3.Name = "Txtphone3"
        Me.Txtphone3.Size = New System.Drawing.Size(133, 26)
        Me.Txtphone3.TabIndex = 8
        '
        'Txthours1
        '
        Me.Txthours1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txthours1.ForeColor = System.Drawing.Color.White
        Me.Txthours1.Location = New System.Drawing.Point(449, 73)
        Me.Txthours1.Name = "Txthours1"
        Me.Txthours1.Size = New System.Drawing.Size(133, 26)
        Me.Txthours1.TabIndex = 9
        '
        'Txthour2
        '
        Me.Txthour2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txthour2.ForeColor = System.Drawing.Color.White
        Me.Txthour2.Location = New System.Drawing.Point(449, 136)
        Me.Txthour2.Name = "Txthour2"
        Me.Txthour2.Size = New System.Drawing.Size(133, 26)
        Me.Txthour2.TabIndex = 10
        '
        'Txthour3
        '
        Me.Txthour3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txthour3.ForeColor = System.Drawing.Color.White
        Me.Txthour3.Location = New System.Drawing.Point(449, 195)
        Me.Txthour3.Name = "Txthour3"
        Me.Txthour3.Size = New System.Drawing.Size(133, 26)
        Me.Txthour3.TabIndex = 11
        '
        'Bntprint
        '
        Me.Bntprint.BackColor = System.Drawing.Color.Gold
        Me.Bntprint.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bntprint.ForeColor = System.Drawing.Color.Black
        Me.Bntprint.Location = New System.Drawing.Point(449, 275)
        Me.Bntprint.Name = "Bntprint"
        Me.Bntprint.Size = New System.Drawing.Size(133, 35)
        Me.Bntprint.TabIndex = 14
        Me.Bntprint.Text = "Print"
        Me.Bntprint.UseVisualStyleBackColor = False
        '
        'Bntnew
        '
        Me.Bntnew.BackColor = System.Drawing.Color.Gold
        Me.Bntnew.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bntnew.ForeColor = System.Drawing.Color.Black
        Me.Bntnew.Location = New System.Drawing.Point(263, 275)
        Me.Bntnew.Name = "Bntnew"
        Me.Bntnew.Size = New System.Drawing.Size(133, 35)
        Me.Bntnew.TabIndex = 15
        Me.Bntnew.Text = "New/Remove"
        Me.Bntnew.UseVisualStyleBackColor = False
        '
        'Bnthome
        '
        Me.Bnthome.BackColor = System.Drawing.Color.Gold
        Me.Bnthome.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bnthome.ForeColor = System.Drawing.Color.Black
        Me.Bnthome.Location = New System.Drawing.Point(54, 275)
        Me.Bnthome.Name = "Bnthome"
        Me.Bnthome.Size = New System.Drawing.Size(133, 35)
        Me.Bnthome.TabIndex = 16
        Me.Bnthome.Text = "Home"
        Me.Bnthome.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(624, 339)
        Me.Controls.Add(Me.Bnthome)
        Me.Controls.Add(Me.Bntnew)
        Me.Controls.Add(Me.Bntprint)
        Me.Controls.Add(Me.Txthour3)
        Me.Controls.Add(Me.Txthour2)
        Me.Controls.Add(Me.Txthours1)
        Me.Controls.Add(Me.Txtphone3)
        Me.Controls.Add(Me.Txtphone2)
        Me.Controls.Add(Me.Txtphone1)
        Me.Controls.Add(Me.Labelhours)
        Me.Controls.Add(Me.Labelphon)
        Me.Controls.Add(Me.Txtemploy3)
        Me.Controls.Add(Me.Txtemploy2)
        Me.Controls.Add(Me.Labelemploy)
        Me.Controls.Add(Me.Txtemploy1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Red
        Me.Name = "Form1"
        Me.Text = "EMPLOYEES"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txtemploy1 As TextBox
    Friend WithEvents Labelemploy As Label
    Friend WithEvents Txtemploy2 As TextBox
    Friend WithEvents Txtemploy3 As TextBox
    Friend WithEvents Labelphon As Label
    Friend WithEvents Labelhours As Label
    Friend WithEvents Txtphone1 As TextBox
    Friend WithEvents Txtphone2 As TextBox
    Friend WithEvents Txtphone3 As TextBox
    Friend WithEvents Txthours1 As TextBox
    Friend WithEvents Txthour2 As TextBox
    Friend WithEvents Txthour3 As TextBox
    Friend WithEvents Bntprint As Button
    Friend WithEvents Bntnew As Button
    Friend WithEvents Bnthome As Button
End Class
